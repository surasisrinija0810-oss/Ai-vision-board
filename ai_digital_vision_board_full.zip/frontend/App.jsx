
// App.jsx (Vision Board main component)
import React, { useEffect, useRef, useState } from "react";
import html2canvas from "html2canvas";

export default function App() {
  const [items, setItems] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const boardRef = useRef(null);

  useEffect(() => {
    const saved = localStorage.getItem("vision-board-items");
    if (saved) setItems(JSON.parse(saved));
    else setItems([]);
  }, []);

  useEffect(() => {
    localStorage.setItem("vision-board-items", JSON.stringify(items));
  }, [items]);

  async function generateImageForItem(id) {
    const item = items.find((i) => i.id === id);
    if (!item) return;
    try {
      const res = await fetch("http://localhost:5000/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: item.prompt, size: "1024x1024" }),
      });
      const data = await res.json();
      if (data.imageUrl) {
        setItems((prev) =>
          prev.map((it) => (it.id === id ? { ...it, imageUrl: data.imageUrl } : it))
        );
      }
    } catch (e) {
      console.error(e);
    }
  }

  function addItem() {
    const newItem = {
      id: Math.random().toString(36).slice(2, 9),
      title: "New Vision",
      note: "Describe your goal...",
      prompt: "A beautiful inspirational scene",
      imageUrl: null,
    };
    setItems((prev) => [newItem, ...prev]);
    setSelectedId(newItem.id);
  }

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">AI Digital Vision Board</h1>
      <button onClick={addItem} className="bg-green-500 text-white px-3 py-2 rounded mb-4">
        + Add Vision
      </button>
      <div ref={boardRef} className="grid grid-cols-3 gap-4">
        {items.map((item) => (
          <div
            key={item.id}
            className="border p-2 rounded shadow cursor-pointer"
            onClick={() => setSelectedId(item.id)}
          >
            {item.imageUrl ? (
              <img src={item.imageUrl} alt={item.title} className="w-full h-40 object-cover" />
            ) : (
              <div className="h-40 bg-gray-200 flex items-center justify-center text-gray-500">
                No image
              </div>
            )}
            <h2 className="font-semibold">{item.title}</h2>
            <p className="text-sm">{item.note}</p>
            <button
              onClick={(e) => {
                e.stopPropagation();
                generateImageForItem(item.id);
              }}
              className="bg-blue-500 text-white text-sm px-2 py-1 rounded mt-2"
            >
              Generate Image
            </button>
          </div>
        ))}
      </div>
      {selectedId && (
        <div className="mt-4 border-t pt-4">
          <h2 className="font-semibold">Edit Selected Vision</h2>
          {(() => {
            const sel = items.find((i) => i.id === selectedId);
            if (!sel) return null;
            return (
              <div className="space-y-2">
                <input
                  value={sel.title}
                  onChange={(e) =>
                    setItems((prev) =>
                      prev.map((it) =>
                        it.id === selectedId ? { ...it, title: e.target.value } : it
                      )
                    )
                  }
                  className="border p-1 w-full"
                />
                <textarea
                  value={sel.note}
                  onChange={(e) =>
                    setItems((prev) =>
                      prev.map((it) =>
                        it.id === selectedId ? { ...it, note: e.target.value } : it
                      )
                    )
                  }
                  className="border p-1 w-full"
                />
                <textarea
                  value={sel.prompt}
                  onChange={(e) =>
                    setItems((prev) =>
                      prev.map((it) =>
                        it.id === selectedId ? { ...it, prompt: e.target.value } : it
                      )
                    )
                  }
                  className="border p-1 w-full"
                />
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}
